/*Apenas termine de cargar el documento entra aqui*/    
window.addEventListener('load', (event) => {
    let miBody = document.body;
       miBody.classList.remove('loader');
});
