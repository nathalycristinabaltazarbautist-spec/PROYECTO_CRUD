import mysql.connector
import bcrypt
from conexionBD import connectionBD

def crear_usuario(username, password):
    conexion = connectionBD()
    cursor = conexion.cursor()
    hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    try:
        cursor.execute("INSERT INTO auth (username, password) VALUES (%s, %s)", (username, hashed))
        conexion.commit()
        return True
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return False
    finally:
        cursor.close()
        conexion.close()

def verificar_usuario(username, password):
    conexion = connectionBD()
    cursor = conexion.cursor(dictionary=True)
    cursor.execute("SELECT * FROM auth WHERE username=%s", (username,))
    usuario = cursor.fetchone()
    cursor.close()
    conexion.close()
    if usuario and bcrypt.checkpw(password.encode('utf-8'), usuario['password'].encode('utf-8')):
        return True
    return False
